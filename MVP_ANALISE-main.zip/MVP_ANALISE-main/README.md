# MVP_ANALISE
Sprint: Análise de Dados e Boas Práticas

Link do projeto MVP no Google Colab:

https://colab.research.google.com/drive/1mV8otTVRAdnn9xAq98BPQ487cGpoMqL6?usp=sharing
